import { db } from "./db";
import {
  bucketListItems,
  projects,
  contacts,
  type InsertBucketListItem,
  type BucketListItem,
  type InsertProject,
  type Project,
  type InsertContact,
  type Contact
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getBucketListItems(): Promise<BucketListItem[]>;
  createBucketListItem(item: InsertBucketListItem): Promise<BucketListItem>;
  getProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  createContact(contact: InsertContact): Promise<Contact>;
}

export class DatabaseStorage implements IStorage {
  async getBucketListItems(): Promise<BucketListItem[]> {
    return await db.select().from(bucketListItems);
  }

  async createBucketListItem(item: InsertBucketListItem): Promise<BucketListItem> {
    const [newItem] = await db.insert(bucketListItems).values(item).returning();
    return newItem;
  }

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    const [newContact] = await db.insert(contacts).values(contact).returning();
    return newContact;
  }
}

export const storage = new DatabaseStorage();
