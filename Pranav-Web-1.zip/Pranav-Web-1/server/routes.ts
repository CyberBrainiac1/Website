import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.bucketList.list.path, async (req, res) => {
    const items = await storage.getBucketListItems();
    res.json(items);
  });

  app.get(api.projects.list.path, async (req, res) => {
    const projects = await storage.getProjects();
    res.json(projects);
  });

  app.post(api.contacts.create.path, async (req, res) => {
    const input = api.contacts.create.input.parse(req.body);
    await storage.createContact(input);
    res.status(201).json({ success: true });
  });

  // Seed data function
  async function seedData() {
    const existing = await storage.getBucketListItems();
    if (existing.length === 0) {
      const items = [
        "Program a humanoid",
        "use RL to train a robot",
        "go to BWSI",
        "design my very own robot arm",
        "design my very own robot hand"
      ];
      
      for (const content of items) {
        await storage.createBucketListItem({ content, isCompleted: false });
      }
    }

    const existingProjects = await storage.getProjects();
    if (existingProjects.length === 0) {
      const initialProjects = [
        {
          title: "Robot arm",
          description: "A custom designed and built robotic arm.",
          imageUrl: "https://images.unsplash.com/photo-1581092160562-40aa08e78837",
          link: "#"
        },
        {
          title: "Robot hand",
          description: "A biologically inspired robotic hand with multiple degrees of freedom.",
          imageUrl: "https://images.unsplash.com/photo-1531746790731-6c087fecd65a",
          link: "#"
        },
        {
          title: "ftc robot 25-26",
          description: "Competitive robot built for the 2025-2026 FTC season.",
          imageUrl: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e",
          link: "#"
        },
        {
          title: "motion sensing robot",
          description: "Built for warrior hacks, this robot reacts to human movement.",
          imageUrl: "https://images.unsplash.com/photo-1546776310-eef45dd6d63c",
          link: "#"
        },
        {
          title: "Solder buddy",
          description: "Built for AMD xHackclub Prototype hackathon. A compact desktop soldering assistant.",
          imageUrl: "https://images.unsplash.com/photo-1517420704952-d9f39e95b43e",
          link: "#"
        },
        {
          title: "ftc robot 24-25",
          description: "Robot built for the 2024-2025 FTC season.",
          imageUrl: "https://images.unsplash.com/photo-1504639725590-34d0984388bd",
          link: "#"
        }
      ];

      for (const p of initialProjects) {
        await storage.createProject(p);
      }
    }
  }

  seedData();

  return httpServer;
}
