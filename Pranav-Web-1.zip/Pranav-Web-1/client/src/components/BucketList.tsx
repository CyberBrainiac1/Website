import { useBucketList } from "@/hooks/use-bucket-list";

export function BucketList() {
  const { data: items, isLoading, isError } = useBucketList();

  if (isLoading) {
    return (
      <div className="card">
        <h3>Robotics Bucket List</h3>
        <p style={{ color: '#9ca3af', fontStyle: 'italic' }}>Loading goals...</p>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="card">
        <h3>Robotics Bucket List</h3>
        <p style={{ color: '#ef4444' }}>Failed to load list.</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h2 style={{ fontSize: '1.5rem' }}>Robotics Bucket List</h2>
      <ul className="bucket-list">
        {items?.map((item) => (
          <li key={item.id} className="bucket-item">
            <div className={`bucket-checkbox ${item.isCompleted ? 'checked' : ''}`} />
            <span className={`bucket-text ${item.isCompleted ? 'completed' : ''}`}>
              {item.content}
            </span>
          </li>
        ))}
        {(!items || items.length === 0) && (
          <li className="bucket-item">
            <span className="bucket-text" style={{ fontStyle: 'italic', opacity: 0.5 }}>
              No active goals yet.
            </span>
          </li>
        )}
      </ul>
    </div>
  );
}
