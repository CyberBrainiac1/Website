export function HeaderDots() {
  return (
    <div className="header-dots">
      <span className="dot dot-orange" />
      <span className="dot dot-green" />
      <span className="dot dot-purple" />
    </div>
  );
}
