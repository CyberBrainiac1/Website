import { useState } from "react";
import { Copy } from "lucide-react";

export function SocialLinks() {
  const [copied, setCopied] = useState(false);

  const handleCopyDiscord = () => {
    navigator.clipboard.writeText("pranav#0000");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="social-links">
      <a 
        href="https://www.linkedin.com/in/pranav-emmadi-874723399/" 
        target="_blank" 
        rel="noopener noreferrer"
        className="social-link"
      >
        LinkedIn
      </a>
      
      <button 
        onClick={handleCopyDiscord}
        className="social-link"
        style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '6px' }}
      >
        Discord
        {copied && <span className="copy-tooltip show">Copied!</span>}
      </button>
      
      <a href="mailto:pranav@example.com" className="social-link">
        Email
      </a>
    </div>
  );
}
