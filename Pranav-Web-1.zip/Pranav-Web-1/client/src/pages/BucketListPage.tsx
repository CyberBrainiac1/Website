import { HeaderDots } from "@/components/HeaderDots";
import { BucketList } from "@/components/BucketList";
import { Link } from "wouter";

export default function BucketListPage() {
  return (
    <div className="container">
      <header style={{ marginBottom: '48px' }}>
        <h1 style={{ fontSize: '3rem', marginBottom: '16px' }}>Bucket List</h1>
        <HeaderDots />
        <Link href="/" style={{ color: 'var(--accent-color)', fontWeight: '500' }}>
          ← Back Home
        </Link>
      </header>

      <div style={{ maxWidth: '600px' }}>
        <BucketList />
      </div>

      <footer className="footer" style={{ marginTop: '64px' }}>
        <span>Always adding new builds.</span>
      </footer>
    </div>
  );
}
