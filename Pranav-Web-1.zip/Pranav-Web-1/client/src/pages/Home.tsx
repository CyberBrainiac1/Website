import { useState } from "react";
import { HeaderDots } from "@/components/HeaderDots";
import { SocialLinks } from "@/components/SocialLinks";
import { BucketList } from "@/components/BucketList";
import { useQuery, useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Home() {
  const [activeTab, setActiveTab] = useState<"about" | "projects" | "bucket">("about");
  const { toast } = useToast();

  const { data: projects } = useQuery({
    queryKey: [api.projects.list.path],
  });

  const contactMutation = useMutation({
    mutationFn: async (data: { name: string; email: string; message: string }) => {
      return await apiRequest("POST", api.contacts.create.path, data);
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Your message has been received!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleContactSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      name: formData.get("name") as string,
      email: formData.get("email") as string,
      message: formData.get("message") as string,
    };
    contactMutation.mutate(data);
    e.currentTarget.reset();
  };

  return (
    <div className="container">
      <div className="grid-layout">
        {/* Left Column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <h1 style={{ fontSize: '2.5rem', lineHeight: '1.1', marginBottom: '8px' }}>Pranav Emmadi</h1>
          <HeaderDots />
          
          <nav className="tab-navigation">
            <button 
              className={`tab-button ${activeTab === 'about' ? 'active' : ''}`}
              onClick={() => setActiveTab('about')}
            >
              About
            </button>
            <button 
              className={`tab-button ${activeTab === 'projects' ? 'active' : ''}`}
              onClick={() => setActiveTab('projects')}
            >
              Projects
            </button>
            <button 
              className={`tab-button ${activeTab === 'bucket' ? 'active' : ''}`}
              onClick={() => setActiveTab('bucket')}
            >
              Bucket List
            </button>
          </nav>

          <SocialLinks />

          <div className="profile-image-placeholder" style={{ marginTop: '16px' }}>
             <span>Photo</span>
          </div>
        </div>

        {/* Right Column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '48px' }}>
          {activeTab === 'about' && (
            <section>
              <p style={{ fontSize: '1.25rem', color: 'var(--accent-color)', fontWeight: '500' }}>
                Hardware-focused robotics builder based in San Jose, CA.
              </p>
              <p>
                I'm a builder at heart, obsessed with the intersection of hardware and code. 
                As the founder of the <strong>FTC Evergreen Dragons (#23425)</strong>, 
                I lead mechanical design and system integration for competitive robotics.
              </p>
              <p>
                My toolkit revolves around high-fidelity CAD in <strong>SolidWorks</strong> and <strong>Onshape</strong>, 
                where I specialize in designing compliant mechanisms and rapid prototyping via 3D printing.
              </p>
              <p>
                Lately, I've been pioneering the use of <strong>NVIDIA Isaac Sim</strong> to bridge the gap between 
                virtual simulation and real-world hardware performance, ensuring our robots are battle-tested before they're built.
              </p>
            </section>
          )}

          {activeTab === 'projects' && (
            <section className="projects-grid">
              <h2 style={{ marginBottom: '24px' }}>Projects</h2>
              <div className="projects-list">
                {projects?.map((project) => (
                  <div key={project.id} className="project-item" style={{ borderBottom: '1px solid rgba(100, 255, 218, 0.1)', paddingBottom: '32px' }}>
                    {project.imageUrl && (
                      <div style={{ overflow: 'hidden', borderRadius: 'var(--radius-md)', border: '1px solid rgba(100, 255, 218, 0.2)' }}>
                        <img src={project.imageUrl} alt={project.title} className="project-image" style={{ transition: 'transform 0.3s ease' }} />
                      </div>
                    )}
                    <h3 style={{ marginTop: '20px', color: 'var(--accent-color)' }}>{project.title}</h3>
                    <p style={{ fontSize: '1.05rem', color: '#ccd6f6' }}>{project.description}</p>
                    {project.link && (
                      <a href={project.link} target="_blank" rel="noopener noreferrer" className="project-link">
                        View Project Archive →
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}

          {activeTab === 'bucket' && (
            <section>
              <h2 style={{ marginBottom: '24px' }}>Robotics Bucket List</h2>
              <BucketList />
            </section>
          )}
          
          <div className="status-indicator">
            <div className="pulsing-dot" />
            <span>Now building: Robotic hand + FTC mechanisms</span>
          </div>
        </div>
      </div>

      <footer className="footer-section">
        <section id="contact" style={{ marginTop: '64px', borderTop: '1px solid rgba(100, 255, 218, 0.1)', paddingTop: '48px' }}>
          <h2 style={{ marginBottom: '32px', textAlign: 'center' }}>Get in Touch</h2>
          <form onSubmit={handleContactSubmit} className="contact-form-horizontal">
            <input type="text" name="name" placeholder="Name" required className="form-input" />
            <input type="email" name="email" placeholder="Email" required className="form-input" />
            <input type="text" name="message" placeholder="Message" required className="form-input flex-1" />
            <button type="submit" className="social-link" style={{ padding: '12px 32px' }} disabled={contactMutation.isPending}>
              {contactMutation.isPending ? '...' : 'Send'}
            </button>
          </form>
        </section>
        
        <div className="footer-bottom">
          <span>&copy; 2026 Pranav Emmadi</span>
          <span>Always adding new builds.</span>
        </div>
      </footer>
    </div>
  );
}
