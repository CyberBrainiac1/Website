import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useBucketList() {
  return useQuery({
    queryKey: [api.bucketList.list.path],
    queryFn: async () => {
      const res = await fetch(api.bucketList.list.path, { credentials: "include" });
      if (!res.ok) throw new Error('Failed to fetch bucket list');
      return api.bucketList.list.responses[200].parse(await res.json());
    },
  });
}
