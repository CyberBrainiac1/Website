## Packages
(none needed)

## Notes
Using plain CSS for styling as requested (no Tailwind utility classes in markup).
Fonts: Google Fonts (DM Sans, Architects Daughter, Playfair Display).
